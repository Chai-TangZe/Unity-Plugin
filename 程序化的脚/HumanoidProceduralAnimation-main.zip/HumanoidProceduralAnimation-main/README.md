# HumanoidProceduralAnimation
A fully procedural approach for humanoïd animation

## Videos
1) https://www.youtube.com/watch?v=AChwSWU4AaU
2) https://www.youtube.com/watch?v=VMRpglAaw6k
3) https://www.youtube.com/watch?v=1A_0AxOvey0
